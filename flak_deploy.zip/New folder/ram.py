from flask import Flask, render_template, request, redirect, url_for, session, flash
import random
import smtplib
import time

from backend import process_resumes_and_attachments

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a strong secret key

# Temporary storage for OTPs (use a database in production)
otp_storage = {}

# Allowed users
ALLOWED_USERS = {
    "maneeshaupender30@gmail.com": "Chawoo@30",
    "saicharan.rajampeta@iitlabs.us": "Db2@Admin",
    "rakeshthallapalli7@gmail.com": "7799590053"
}

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/', methods=['POST'])
def login_post():
    email = request.form['email']
    password = request.form['password']
    
    # Check if user is in allowed users
    if email in ALLOWED_USERS and ALLOWED_USERS[email] == password:
        session['user'] = email  # Set session for the logged-in user
        return redirect(url_for('index'))  # Redirect to resume shortlisting page
    else:
        flash("Invalid credentials. Please try again.", "danger")
        return redirect(url_for('login'))

@app.route('/index', methods=["GET", "POST"])  # Correct route definition
def index():
    if 'user' not in session:  # Check if the user is logged in
        return redirect(url_for('login'))
    
    if request.method == "POST":
        job_id = request.form["job_id"]
        start_time = time.time()
        df = process_resumes_and_attachments(job_id)
        end_time = time.time()
        print(f"Data processing took {end_time - start_time:.2f} seconds.")

        df_cleaned = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)
        return render_template("index.html", tables=[df_cleaned.to_html(classes='table table-bordered')])
    
    return render_template("index.html")

@app.route('/forgot_password')
def forgot_password():
    return render_template('forgot_password.html')

@app.route('/forgot_password', methods=['POST'])
def send_otp():
    email = request.form['email']
    otp = str(random.randint(100000, 999999))
    otp_storage[email] = otp  # Store OTP temporarily
    
    # Simulate sending OTP via email (Replace with actual SMTP setup)
    print(f"OTP for {email}: {otp}")
    flash("OTP sent to your email.", "success")
    return redirect(url_for('confirm_otp'))

@app.route('/confirm_otp')
def confirm_otp():
    return render_template('confirm_otp.html')

@app.route('/confirm_otp', methods=['POST'])
def verify_otp():
    email = request.form.get('email')
    otp = request.form['otp']
    
    if email in otp_storage and otp_storage[email] == otp:
        session['reset_email'] = email
        return redirect(url_for('reset_password'))
    else:
        flash("Invalid OTP. Please try again.", "danger")
        return redirect(url_for('confirm_otp'))

@app.route('/reset_password')
def reset_password():
    return render_template('reset_password.html')

@app.route('/reset_password', methods=['POST'])
def reset_password_post():
    if 'reset_email' not in session:
        return redirect(url_for('login'))
    
    new_password = request.form['new_password']
    confirm_password = request.form['confirm_password']
    
    if new_password == confirm_password:
        flash("Password reset successfully. Please log in.", "success")
        return redirect(url_for('login'))
    else:
        flash("Passwords do not match. Try again.", "danger")
        return redirect(url_for('reset_password'))

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
